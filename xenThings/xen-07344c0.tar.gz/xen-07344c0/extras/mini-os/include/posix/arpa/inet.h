#ifndef _POSIX_ARPA_INET_H_
#define	_POSIX_ARPA_INET_H_

#include <lwip/inet.h>

#endif /* _POSIX_ARPA_INET_H_ */

