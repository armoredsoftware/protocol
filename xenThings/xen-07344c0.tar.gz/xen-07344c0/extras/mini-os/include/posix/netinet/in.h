#ifndef _POSIX_SYS_IN_H_
#define _POSIX_SYS_IN_H_

#include <fcntl.h>
#include <lwip/sockets.h>

#endif /* _POSIX_SYS_IN_H_ */
