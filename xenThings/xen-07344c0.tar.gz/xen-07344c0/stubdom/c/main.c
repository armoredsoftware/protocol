#include <stdio.h>
#include <unistd.h>

int main(void) {
        sleep(2);
        printf("Hello, world!\n");
        return 0;
}
